#pragma once

#include <chrono>
using dmilliseconds = std::chrono::duration<long double, std::milli>;

class Timer
{
public:
	Timer() = default;

	void Start()
	{
		start = std::chrono::duration_cast<dmilliseconds>(std::chrono::steady_clock::now().time_since_epoch());
		is_start = true;
	}

	void Stop()
	{
		stop = std::chrono::duration_cast<dmilliseconds>(std::chrono::steady_clock::now().time_since_epoch());
		is_start = false;
	}

	dmilliseconds GetTime() const
	{
		if (is_start)
			return std::chrono::duration_cast<dmilliseconds>(std::chrono::steady_clock::now().time_since_epoch()) - start;
		return (stop - start);
	}

	bool isStart() const
	{
		return is_start;
	}

	~Timer() = default;

private:
	bool is_start = false;
	dmilliseconds start;
	dmilliseconds stop;
};