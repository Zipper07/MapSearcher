#include "Window.h"
#include "Menu.h"
#include "resource.h"
#include <wtypes.h>

#define GLFW_EXPOSE_NATIVE_WIN32
#include <GLFW/glfw3native.h>

using namespace std::chrono;

GLFWwindow* Window::window = nullptr;

double Window::fpsLimit = 60.0;
int Window::fpsLimitMode = 1;

using dmilliseconds = duration<long double, std::milli>;
dmilliseconds Window::clock, Window::newclock, Window::deltaticks;

bool Window::Init()
{
    if (!Menu::Init())
        return false;

    return true;
}

static void error_callback(int error, const char* description)
{
    fprintf(stderr, "Error: %s\n", description);
}

bool Window::Create(const char* title, point size)
{
    glfwSetErrorCallback(error_callback);

    if (!glfwInit())
        return false;

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    window = glfwCreateWindow(size.x, size.y, title, nullptr, nullptr);
    if (!window)
        return false;

    HICON hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(MYICONAPP));
    if (hIcon)
    {
        HWND hwnd = glfwGetWin32Window(window);
        SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
        SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
    }

    glfwMakeContextCurrent(window);
    gladLoadGL();
    glfwSwapInterval(1);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::StyleColorsDark();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = "";

    ImFontConfig font_config;
    font_config.OversampleH = 2;
    font_config.OversampleV = 1;
    font_config.PixelSnapH = 1;
    static const ImWchar ranges[] =
    {
        0x0020, 0x00FF,
        0x0400, 0x044F,
        0,
    };
    io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\Tahoma.ttf", 24.0f, &font_config, ranges);
    //io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\Tahoma.ttf", 24.f, nullptr, io.Fonts->GetGlyphRangesCyrillic());

    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 330");

    return true;
}

void Window::Run()
{
    while (!glfwWindowShouldClose(window))
    {
        NewFrame();

        Menu::Draw();

        Render();
    }
}

GLFWwindow* Window::GetWindow()
{
    return window;
}

bool Window::isOpen()
{
    return !glfwWindowShouldClose(window);
}

void Window::SetSize(point size)
{
    glfwGetWindowSize(window, &size.x, &size.y);
    glfwRestoreWindow(window);
}
void Window::SetPos(point pos)
{
    glfwGetWindowPos(window, &pos.x, &pos.y);
    glfwRestoreWindow(window);
}
point Window::GetSize()
{
    int x, y;
    glfwGetWindowSize(window, &x, &y);
    return point(x, y);
}
point Window::GetPos()
{
    int x, y;
    glfwGetWindowPos(window, &x, &y);
    return point(x, y);
}
/*
void Window::SetDisplayMode(int displayMode)
{
    if (displayMode == 0)
        SDL_SetWindowFullscreen(window, 0);
    else if (displayMode == 1)
        SDL_SetWindowFullscreen(window, SDL_WINDOW_FULLSCREEN_DESKTOP);
    else if (displayMode == 2)
        SDL_SetWindowFullscreen(window, SDL_WINDOW_FULLSCREEN);
}
*/
void Window::SetFPSLimitMode(int mode, double custom_fps)
{
    if (mode > 2 || mode < 0)
        return;

    fpsLimitMode = mode;
    if (fpsLimitMode == 0)
        glfwSwapInterval(0);
    else if (fpsLimitMode == 1)
        glfwSwapInterval(1);
    else if (fpsLimitMode == 2)
    {
        glfwSwapInterval(0);
        fpsLimit = round(custom_fps * 10.0) / 10.0;
    }
}

void Window::SetIcon(const GLFWimage* icon)
{
    glfwSetWindowIcon(window, 1, icon);
}

void Window::Destroy()
{
    glfwSetWindowShouldClose(window, GLFW_TRUE);

    Menu::Destroy();

    if (ImGui::GetCurrentContext())
    {
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplGlfw_Shutdown();
        ImGui::DestroyContext();
    }

    if (window)
        glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}

void Window::NewFrame()
{
    glClear(GL_COLOR_BUFFER_BIT);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplGlfw_NewFrame();
    ImGui::NewFrame();
}

void Window::Render()
{
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    glfwSwapBuffers(window);
    glfwPollEvents();

    if (fpsLimitMode == 2)
        FPSLimiter();
}

void Window::FPSLimiter()
{
    newclock = duration_cast<dmilliseconds>(steady_clock::now().time_since_epoch());
    deltaticks = dmilliseconds(1000.0 / fpsLimit) - (newclock - clock);

    if (deltaticks > 0ms)
        std::this_thread::sleep_for(deltaticks);

    if (deltaticks < -30ms)
        clock = newclock - 30ms;
    else
        clock = newclock + deltaticks;
}