#pragma once
#include <iostream>
#include <string>

#include <cassert>
#include <sstream>
#include <iomanip>

#ifdef IMGUI_VERSION
#define IMGUI_INCLUDED 1
#else
#define IMGUI_INCLUDED 0
#endif

template<typename T = int>
class Point
{
public:
	T x, y;

	Point();
	Point(const T& s);
	Point(const T& x, const T& y);
	Point(const Point& p);

	template<typename Type>
	Point(const Type& s);
	template<typename Type>
	Point(const Type& x, const Type& y);
	template<typename A, typename B>
	Point(const A& x, const B& y);
	template<typename Type>
	Point(const Point<Type>& p);

	Point operator =(const T& s);
	Point operator =(const Point& p);

	template<typename Type>
	Point operator =(const Type& s);
	template<typename Type>
	Point operator =(const Point<Type>& p);


	T& operator [](int i);
	const T& operator [](int i) const;

	Point& operator ++();
	Point operator ++(int);
	Point& operator --();
	Point operator --(int);
	Point operator +();
	Point operator -();

	Point operator +=(T s);
	Point operator -=(T s);
	Point operator *=(T s);
	Point operator /=(T s);

	Point operator +=(Point p);
	Point operator -=(Point p);
	Point operator *=(Point p);
	Point operator /=(Point p);

	template<typename Type>
	Point operator +=(Type s);
	template<typename Type>
	Point operator -=(Type s);
	template<typename Type>
	Point operator *=(Type s);
	template<typename Type>
	Point operator /=(Type s);

	template<typename Type>
	Point operator +=(Point<Type> p);
	template<typename Type>
	Point operator -=(Point<Type> p);
	template<typename Type>
	Point operator *=(Point<Type> p);
	template<typename Type>
	Point operator /=(Point<Type> p);

	Point operator +(T s);
	Point operator -(T s);
	Point operator *(T s);
	Point operator /(T s);

	Point operator +(Point p);
	Point operator -(Point p);
	Point operator *(Point p);
	Point operator /(Point p);

	template<typename Type>
	Point operator +(Type s);
	template<typename Type>
	Point operator -(Type s);
	template<typename Type>
	Point operator *(Type s);
	template<typename Type>
	Point operator /(Type s);

	template<typename Type>
	Point operator +(Point<Type> p);
	template<typename Type>
	Point operator -(Point<Type> p);
	template<typename Type>
	Point operator *(Point<Type> p);
	template<typename Type>
	Point operator /(Point<Type> p);


	bool operator ==(T s);
	bool operator !=(T s);
	bool operator >(T s);
	bool operator <(T s);
	bool operator >=(T s);
	bool operator <=(T s);

	bool operator ==(Point p);
	bool operator !=(Point p);
	bool operator >(Point p);
	bool operator <(Point p);
	bool operator >=(Point p);
	bool operator <=(Point p);

	template<typename Type>
	bool operator ==(Type s);
	template<typename Type>
	bool operator !=(Type s);
	template<typename Type>
	bool operator >(Type s);
	template<typename Type>
	bool operator <(Type s);
	template<typename Type>
	bool operator >=(Type s);
	template<typename Type>
	bool operator <=(Type s);

	template<typename Type>
	bool operator ==(Point<Type> p);
	template<typename Type>
	bool operator !=(Point<Type> p);
	template<typename Type>
	bool operator >(Point<Type> p);
	template<typename Type>
	bool operator <(Point<Type> p);
	template<typename Type>
	bool operator >=(Point<Type> p);
	template<typename Type>
	bool operator <=(Point<Type> p);



#if IMGUI_INCLUDED
	Point(const ImVec2& v);
	operator ImVec2() const;
	Point operator =(const ImVec2& v);
#endif



	bool isValid();
	Point& Abs();
	Point& limitX(const T& min, const T& max);
	Point& limitY(const T& min, const T& max);
	Point& limit(const T& min, const T& max);
	std::string toString(int precision = -1);
};

using point = Point<>;
using pointd = Point<double>;
using pointf = Point<float>;




template<typename T>
Point<T>::Point()
	: x(0), y(0) {}

template<typename T>
Point<T>::Point(const T& s)
	: x(s), y(s) {}

template<typename T>
Point<T>::Point(const T& x, const T& y)
	: x(x), y(y) {}

template<typename T>
Point<T>::Point(const Point& p)
	: x(p.x), y(p.y) {}



template<typename T>
template<typename Type>
Point<T>::Point(const Type& s)
	: x(static_cast<T>(s)), y(static_cast<T>(s)) {}

template<typename T>
template<typename Type>
Point<T>::Point(const Type& x, const Type& y)
	: x(static_cast<T>(x)), y(static_cast<T>(y)) {}

template<typename T>
template<typename A, typename B>
Point<T>::Point(const A& x, const B& y)
	: x(static_cast<T>(x)), y(static_cast<T>(y)) {}

template<typename T>
template<typename Type>
Point<T>::Point(const Point<Type>& p)
	: x(static_cast<T>(p.x)), y(static_cast<T>(p.y)) {}



template<typename T>
Point<T> Point<T>::operator =(const T& s)
{
	x = y = s;
	return *this;
}

template<typename T>
Point<T> Point<T>::operator =(const Point& p)
{
	x = p.x;
	y = p.y;
	return *this;
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator =(const Type& s)
{
	x = y = static_cast<T>(s);
	return *this;
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator =(const Point<Type>& p)
{
	x = static_cast<T>(p.x);
	y = static_cast<T>(p.y);
	return *this;
}



template<typename T>
T& Point<T>::operator [](int i)
{
	assert(i >= 0 && i < 2 && "OUT OF RANGE");
	if (i)
		return y;
	return x;
}

template<typename T>
const T& Point<T>::operator [](int i) const
{
	assert(i >= 0 && i < 2 && "OUT OF RANGE");
	if (i)
		return y;
	return x;
}



template<typename T>
Point<T>& Point<T>::operator ++()
{
	x++;
	y++;
	return *this;
}

template<typename T>
Point<T> Point<T>::operator ++(int)
{
	Point p = *this;
	x++;
	y++;
	return p;
}

template<typename T>
Point<T>& Point<T>::operator --()
{
	x--;
	y--;
	return *this;
}

template<typename T>
Point<T> Point<T>::operator --(int)
{
	Point p = *this;
	x--;
	y--;
	return p;
}

template<typename T>
Point<T> Point<T>::operator +()
{
	return *this;
}

template<typename T>
Point<T> Point<T>::operator -()
{
	return Point(-x, -y);
}



template<typename T>
Point<T> Point<T>::operator +=(T s)
{
	x += s;
	y += s;
	return *this;
}

template<typename T>
Point<T> Point<T>::operator -=(T s)
{
	x -= s;
	y -= s;
	return *this;
}

template<typename T>
Point<T> Point<T>::operator *=(T s)
{
	x *= s;
	y *= s;
	return *this;
}

template<typename T>
Point<T> Point<T>::operator /=(T s)
{
	assert(s != 0 && "DIVISION BY ZERO");
	x /= s;
	y /= s;
	return *this;
}



template<typename T>
Point<T> Point<T>::operator +=(Point p)
{
	x += p.x;
	y += p.y;
	return *this;
}

template<typename T>
Point<T> Point<T>::operator -=(Point p)
{
	x -= p.x;
	y -= p.y;
	return *this;
}

template<typename T>
Point<T> Point<T>::operator *=(Point p)
{
	x *= p.x;
	y *= p.y;
	return *this;
}

template<typename T>
Point<T> Point<T>::operator /=(Point p)
{
	assert(p.isValid() && "DIVISION BY ZERO");
	x /= p.x;
	y /= p.y;
	return *this;
}



template<typename T>
template<typename Type>
Point<T> Point<T>::operator +=(Type s)
{
	x += static_cast<T>(s);
	y += static_cast<T>(s);
	return *this;
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator -=(Type s)
{
	x -= static_cast<T>(s);
	y -= static_cast<T>(s);
	return *this;
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator *=(Type s)
{
	x *= static_cast<T>(s);
	y *= static_cast<T>(s);
	return *this;
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator /=(Type s)
{
	assert(s != 0 && "DIVISION BY ZERO");
	x /= static_cast<T>(s);
	y /= static_cast<T>(s);
	return *this;
}



template<typename T>
template<typename Type>
Point<T> Point<T>::operator +=(Point<Type> p)
{
	x += static_cast<T>(p.x);
	y += static_cast<T>(p.y);
	return *this;
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator -=(Point<Type> p)
{
	x -= static_cast<T>(p.x);
	y -= static_cast<T>(p.y);
	return *this;
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator *=(Point<Type> p)
{
	x *= static_cast<T>(p.x);
	y *= static_cast<T>(p.y);
	return *this;
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator /=(Point<Type> p)
{
	assert(p.isValid() && "DIVISION BY ZERO");
	x /= static_cast<T>(p.x);
	y /= static_cast<T>(p.y);
	return *this;
}



template<typename T>
Point<T> Point<T>::operator +(T s)
{
	return Point(x + s, y + s);
}

template<typename T>
Point<T> Point<T>::operator -(T s)
{
	return Point(x - s, y - s);
}

template<typename T>
Point<T> Point<T>::operator *(T s)
{
	return Point(x * s, y * s);
}

template<typename T>
Point<T> Point<T>::operator /(T s)
{
	assert(s && "DIVISION BY ZERO");
	return Point(x / s, y / s);
}



template<typename T>
Point<T> Point<T>::operator +(Point p)
{
	return Point(x + p.x, y + p.y);
}

template<typename T>
Point<T> Point<T>::operator -(Point p)
{
	return Point(x - p.x, y - p.y);
}

template<typename T>
Point<T> Point<T>::operator *(Point p)
{
	return Point(x * p.x, y * p.y);
}

template<typename T>
Point<T> Point<T>::operator /(Point p)
{
	assert(p.isValid() && "DIVISION BY ZERO");
	return Point(x / p.x, y / p.y);
}



template<typename T>
template<typename Type>
Point<T> Point<T>::operator +(Type s)
{
	return Point(x + static_cast<T>(s), y + static_cast<T>(s));
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator -(Type s)
{
	return Point(x - static_cast<T>(s), y - static_cast<T>(s));
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator *(Type s)
{
	return Point(x * static_cast<T>(s), y * static_cast<T>(s));
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator /(Type s)
{
	assert(s && "DIVISION BY ZERO");
	return Point(x / static_cast<T>(s), y / static_cast<T>(s));
}



template<typename T>
template<typename Type>
Point<T> Point<T>::operator +(Point<Type> p)
{
	return Point(x + static_cast<T>(p.x), y + static_cast<T>(p.y));
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator -(Point<Type> p)
{
	return Point(x - static_cast<T>(p.x), y - static_cast<T>(p.y));
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator *(Point<Type> p)
{
	return Point(x * static_cast<T>(p.x), y * static_cast<T>(p.y));
}

template<typename T>
template<typename Type>
Point<T> Point<T>::operator /(Point<Type> p)
{
	assert(p.isValid() && "DIVISION BY ZERO");
	return Point(x / static_cast<T>(p.x), y / static_cast<T>(p.y));
}



template<typename T>
bool Point<T>::operator ==(T s)
{
	return (x == s && y == s);
}

template<typename T>
bool Point<T>::operator !=(T s)
{
	return (x != s && y != s);
}

template<typename T>
bool Point<T>::operator >(T s)
{
	return (x > s && y > s);
}

template<typename T>
bool Point<T>::operator <(T s)
{
	return (x < s&& y < s);
}

template<typename T>
bool Point<T>::operator >=(T s)
{
	return (x >= s && y >= s);
}

template<typename T>
bool Point<T>::operator <=(T s)
{
	return (x <= s && y <= s);
}



template<typename T>
bool Point<T>::operator ==(Point p)
{
	return (x == p.x && y == p.y);
}

template<typename T>
bool Point<T>::operator !=(Point p)
{
	return (x != p.x && y != p.y);
}

template<typename T>
bool Point<T>::operator >(Point p)
{
	return (x > p.x && y > p.y);
}

template<typename T>
bool Point<T>::operator <(Point p)
{
	return (x < p.x&& y < p.y);
}

template<typename T>
bool Point<T>::operator >=(Point p)
{
	return (x >= p.x && y >= p.y);
}

template<typename T>
bool Point<T>::operator <=(Point p)
{
	return (x <= p.x && y <= p.y);
}



template<typename T>
template<typename Type>
bool Point<T>::operator ==(Type s)
{
	return (x == static_cast<T>(s) && y == static_cast<T>(s));
}

template<typename T>
template<typename Type>
bool Point<T>::operator !=(Type s)
{
	return (x != static_cast<T>(s) && y != static_cast<T>(s));
}


template<typename T>
template<typename Type>
bool Point<T>::operator >(Type s)
{
	return (x > static_cast<T>(s) && y > static_cast<T>(s));
}

template<typename T>
template<typename Type>
bool Point<T>::operator <(Type s)
{
	return (x < static_cast<T>(s) && y < static_cast<T>(s));
}

template<typename T>
template<typename Type>
bool Point<T>::operator >=(Type s)
{
	return (x >= static_cast<T>(s) && y >= static_cast<T>(s));
}

template<typename T>
template<typename Type>
bool Point<T>::operator <=(Type s)
{
	return (x <= static_cast<T>(s) && y <= static_cast<T>(s));
}



template<typename T>
template<typename Type>
bool Point<T>::operator ==(Point<Type> p)
{
	return (x == static_cast<T>(p.x) && y == static_cast<T>(p.y));
}

template<typename T>
template<typename Type>
bool Point<T>::operator !=(Point<Type> p)
{
	return (x != static_cast<T>(p.x) && y != static_cast<T>(p.y));
}

template<typename T>
template<typename Type>
bool Point<T>::operator >(Point<Type> p)
{
	return (x > static_cast<T>(p.x) && y > static_cast<T>(p.y));
}

template<typename T>
template<typename Type>
bool Point<T>::operator <(Point<Type> p)
{
	return (x < static_cast<T>(p.x) && y < static_cast<T>(p.y));
}

template<typename T>
template<typename Type>
bool Point<T>::operator >=(Point<Type> p)
{
	return (x >= static_cast<T>(p.x) && y >= static_cast<T>(p.y));
}

template<typename T>
template<typename Type>
bool Point<T>::operator <=(Point<Type> p)
{
	return (x <= static_cast<T>(p.x) && y <= static_cast<T>(p.y));
}



#if IMGUI_INCLUDED
template<typename T>
Point<T>::Point(const ImVec2& v)
{
	x = v.x;
	y = v.y;
}

template<typename T>
Point<T>::operator ImVec2() const
{
	return ImVec2(x, y);
}

template<typename T>
Point<T> Point<T>::operator =(const ImVec2& v)
{
	x = v.x;
	y = v.y;
	return *this;
}
#endif



template<typename T>
bool Point<T>::isValid()
{
	return (x && y);
}

template<typename T>
Point<T>& Point<T>::Abs()
{
	x.abs();
	y.abs();
	return *this;
}

template<typename T>
Point<T>& Point<T>::limitX(const T& min, const T& max)
{
	if (x > max) x = max;
	else if (x < min) x = min;
	return *this;
}

template<typename T>
Point<T>& Point<T>::limitY(const T& min, const T& max)
{
	if (y > max) y = max;
	else if (y < min) y = min;
	return *this;
}

template<typename T>
Point<T>& Point<T>::limit(const T& min, const T& max)
{
	limitX(min, max);
	limitY(min, max);
	return *this;
}

template<typename T>
std::string Num2Str(const T& num, int precision)
{
	std::ostringstream stream;
	stream << std::fixed << std::setprecision(precision) << num;
	return stream.str();
}

template<typename T>
std::string Point<T>::toString(int precision)
{
	if (precision == -1)
		return "(" + std::to_string(x) + ", " + std::to_string(y) + ")";
	return "(" + Num2Str(x, precision) + ", " + Num2Str(y, precision) + ")";
}

template<typename T>
std::ostream& operator<<(std::ostream& os, const Point<T>& p)
{
	os << "(" << p.x << ", " << p.y << ")";
	return os;
}