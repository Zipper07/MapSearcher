﻿#include <iostream>
#include <vector>
#include <string>
#include <thread>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <filesystem>
#include <Windows.h>
#include <sstream>
#include <fstream>
#include <sys/stat.h>

#include "SimpleTimer.h"
#include "tabulate.hpp"

using namespace tabulate;
namespace fs = std::filesystem;
using namespace std;

Timer timer;
wstring osu = L"F:\\osu!\\Songs";
vector<wstring> p = { L"C:\\Users\\Zipper\\Desktop\\0", L"C:\\Users\\Zipper\\Desktop\\1", L"C:\\Users\\Zipper\\Desktop\\2", L"C:\\Users\\Zipper\\Desktop\\3", L"C:\\Users\\Zipper\\Desktop\\4" };

namespace v1
{
    vector<wstring> files;
    unordered_set<wstring> folders;
    vector<char> duplMaps;
    vector<char> selMaps;
    int countDuplMaps = 0;
    int countSelMaps = 0;

    void GetFiles(vector<wstring>& files, const wstring& path, const wchar_t* extension)
    {
        WIN32_FIND_DATAW findData;
        HANDLE hf;
        wstring name = L"";
        size_t pos = 0;
        files.clear();

        hf = FindFirstFileExW((path + L"\\*").c_str(), FindExInfoBasic, &findData, FindExSearchNameMatch, nullptr, FIND_FIRST_EX_LARGE_FETCH);
        if (hf == INVALID_HANDLE_VALUE)
            return;

        do
        {
            if (findData.dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE)
            {
                name = findData.cFileName;
                pos = name.rfind(extension);
                if (pos != string::npos)
                    files.push_back(name.erase(pos));
            }
        } while (FindNextFileW(hf, &findData));

        FindClose(hf);
    }
    void GetDirs(unordered_set<wstring>& folders, const wstring& path)
    {
        WIN32_FIND_DATAW findData;
        HANDLE hf;
        wstring name = L"";
        folders.clear();

        hf = FindFirstFileExW((path + L"\\*").c_str(), FindExInfoBasic, &findData, FindExSearchNameMatch, nullptr, 0);
        if (hf == INVALID_HANDLE_VALUE)
            return;

        do
        {
            if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                folders.emplace(findData.cFileName);
        } while (FindNextFileW(hf, &findData));

        FindClose(hf);
    }

    void Cmp()
    {
        const auto& end = folders.end();
        wstring tmp = L"";

        #pragma omp parallel for num_threads(2) private(tmp)
        for (int i = 0; i < files.size(); ++i)
        {
            tmp = files[i];
            std::erase(tmp, '.');
            if (folders.find(tmp) != end)
                duplMaps[i] = true;
        }
    }
    void Find()
    {
        int N = files.size();
        for (int i = 0; i < N - 1; i++)
        {
            for (int j = 1; j < N - i; ++j)
            {
                if (files[i + j].find(files[i]) != std::string::npos)
                    duplMaps[i + j] = true;
                else
                {
                    i += j - 1;
                    break;
                }
            }
        }
    }
}

namespace v2
{
    struct File
    {
        wstring name = L"";
        unsigned long weight = 0;
    };

    vector<File> files;
    unordered_set<wstring> folders;
    vector<char> duplMaps;
    vector<char> selMaps;
    int selPath = 0;

    void GetDirs(unordered_set<wstring>& folders, const wstring& path)
    {
        WIN32_FIND_DATAW findData;
        HANDLE hf;
        wstring name = L"";
        folders.clear();

        hf = FindFirstFileExW((path + L"\\*").c_str(), FindExInfoBasic, &findData, FindExSearchNameMatch, nullptr, 0);
        if (hf == INVALID_HANDLE_VALUE)
            return;

        do
        {
            if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                folders.emplace(findData.cFileName);
        } while (FindNextFileW(hf, &findData));

        FindClose(hf);
    }
    void GetFiles(vector<File>& files, const wstring& path, const wchar_t* extension)
    {
        WIN32_FIND_DATAW findData;
        HANDLE hf;
        wstring name = L"";
        size_t pos = 0;
        files.clear();

        hf = FindFirstFileExW((path + L"\\*").c_str(), FindExInfoBasic, &findData, FindExSearchNameMatch, nullptr, FIND_FIRST_EX_LARGE_FETCH);
        if (hf == INVALID_HANDLE_VALUE)
            return;

        File f;
        do
        {
            if (findData.dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE)
            {
                name = findData.cFileName;
                pos = name.rfind(extension);
                if (pos != string::npos)
                {
                    f.name = name.erase(pos);
                    f.weight = (findData.nFileSizeHigh * (MAXDWORD + 1)) + findData.nFileSizeLow;
                    files.push_back(f);
                }
            }
        } while (FindNextFileW(hf, &findData));

        FindClose(hf);
    }

    unsigned long long GetFileSize(const wstring& file)
    {
        WIN32_FILE_ATTRIBUTE_DATA fData;
        if (GetFileAttributesEx(file.c_str(), GetFileExInfoStandard, &fData))
            return (fData.nFileSizeHigh * (MAXDWORD + 1)) + fData.nFileSizeLow;
        return 0;
    }

    void Find()
    {
        int N = files.size();
        for (int i = 0; i < N - 1; i++)
        {
            File& file1 = files[i];
            for (int j = 1; j < N - i; ++j)
            {
                File& file2 = files[i + j];

                if (file2.name.find(file1.name) != std::string::npos && file2.weight == file1.weight)
                    duplMaps[i + j] = 1;
                else
                {
                    i += j - 1;
                    break;
                }
            }
        }
    }
    void Cmp()
    {
        const auto& end = folders.end();
        wstring tmp = L"";

        #pragma omp parallel for num_threads(2) private(tmp)
        for (int i = 0; i < files.size(); ++i)
        {
            if (duplMaps[i])
                continue;

            tmp = files[i].name;
            std::erase(tmp, '.');
            if (folders.find(tmp) != end)
                duplMaps[i] = 2;
        }
    }
}


std::string ToString(double number)
{
    std::ostringstream stream;
    stream.precision(4); //знаки после зяпятой
    stream << std::fixed << number;
    return stream.str();
}
int main()
{
    setlocale(LC_ALL, "ru");

    int N = 50;
    vector<vector<long double>> avr_time{ { 0.0, 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0, 0.0 } };
    vector<vector<long double>> avr_time2{ { 0.0, 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0, 0.0 } };
    vector<vector<int>> results{ { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } };

    {
        Table tb;
        tb.add_row({ "Func", "", "p0", "Speedup", "Result", "", "p1", "Speedup", "Result", "", "p2", "Speedup", "Result", "", "p3", "Speedup", "Result" });
        v1::GetDirs(v1::folders, osu);

        for (int i = 0; i < 4; ++i)
        {
            for (int j = 0; j < N; ++j)
            {
                timer.Start();
                v1::GetFiles(v1::files, p[i], L".osz");
                timer.Stop();
                avr_time[0][i] += timer.GetTime().count();
            }
            avr_time[0][i] /= N;
            results[0][i] = v1::files.size();

            timer.Start();
            sort(v1::files.begin(), v1::files.end());
            timer.Stop();
            avr_time[1][i] = timer.GetTime().count();

            v1::duplMaps.assign(v1::files.size(), false);

            for (int j = 0; j < N; ++j)
            {
                timer.Start();
                v1::Find();
                timer.Stop();
                avr_time[2][i] += timer.GetTime().count();
            }
            avr_time[2][i] /= N;
            for (char& f : v1::duplMaps)
            {
                results[2][i] += f ? 1 : 0;
                f = false;
            }

            for (int j = 0; j < N; ++j)
            {
                timer.Start();
                v1::Cmp();
                timer.Stop();
                avr_time[3][i] += timer.GetTime().count();
            }
            avr_time[3][i] /= N;
            for (char& f : v1::duplMaps)
            {
                results[3][i] += f ? 1 : 0;
                f = false;
            }
        }

        for (int i = 0; i < 4; ++i)
        {
            string func = "";
            if (i == 0)
                func = "GetFiles";
            else if (i == 1)
                func = "sort";
            else if (i == 2)
                func = "Find";
            else if (i == 3)
                func = "Cmp";
            tb.add_row({ func,
                         "", ToString(avr_time[i][0]) + "ms", ToString(1.0), ToString(results[i][0]),
                         "", ToString(avr_time[i][1]) + "ms", ToString(1.0), ToString(results[i][1]),
                         "", ToString(avr_time[i][2]) + "ms", ToString(1.0), ToString(results[i][2]),
                         "", ToString(avr_time[i][3]) + "ms", ToString(1.0), ToString(results[i][3]) });
        }

        tb.column(2).format().font_align(FontAlign::right);
        tb.column(3).format().font_align(FontAlign::right);
        tb.column(4).format().font_align(FontAlign::center);

        tb.column(6).format().font_align(FontAlign::right);
        tb.column(7).format().font_align(FontAlign::right);
        tb.column(8).format().font_align(FontAlign::center);

        tb.column(10).format().font_align(FontAlign::right);
        tb.column(11).format().font_align(FontAlign::right);
        tb.column(12).format().font_align(FontAlign::center);

        tb.column(14).format().font_align(FontAlign::right);
        tb.column(15).format().font_align(FontAlign::right);
        tb.column(16).format().font_align(FontAlign::center);

        for (size_t i = 0; i < tb.row(0).size(); ++i)
        {
            tb[0][i].format()
                .font_color(Color::yellow)
                .font_align(FontAlign::center)
                .font_style({ FontStyle::bold });
        }

        cout << tb << endl << endl;
    }

    results = { { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } };
    {
        Table tb;
        tb.add_row({ "Func", "", "p0", "Speedup", "Result", "", "p1", "Speedup", "Result", "", "p2", "Speedup", "Result", "", "p3", "Speedup", "Result" });
        v2::GetDirs(v2::folders, osu);

        for (int i = 0; i < 4; ++i)
        {
            v2::selPath = i;

            for (int j = 0; j < N; ++j)
            {
                timer.Start();
                v2::GetFiles(v2::files, p[i], L".osz");
                timer.Stop();
                avr_time2[0][i] += timer.GetTime().count();
            }
            avr_time2[0][i] /= N;
            results[0][i] = v2::files.size();

            timer.Start();
            sort(v2::files.begin(), v2::files.end(), [](const v2::File& a, const v2::File& b) { return a.name < b.name; });
            timer.Stop();
            avr_time2[1][i] = timer.GetTime().count();

            v2::duplMaps.assign(v2::files.size(), false);

            for (int j = 0; j < N; ++j)
            {
                timer.Start();
                v2::Find();
                timer.Stop();
                avr_time2[2][i] += timer.GetTime().count();
            }
            avr_time2[2][i] /= N;
            for (char& f : v2::duplMaps)
            {
                results[2][i] += f ? 1 : 0;
                f = false;
            }

            for (int j = 0; j < N; ++j)
            {
                timer.Start();
                v2::Cmp();
                timer.Stop();
                avr_time2[3][i] += timer.GetTime().count();
            }
            avr_time2[3][i] /= N;
            for (char& f : v2::duplMaps)
            {
                results[3][i] += f ? 1 : 0;
                f = false;
            }
        }

        for (int i = 0; i < 4; ++i)
        {
            string func = "";
            if (i == 0)
                func = "GetFiles";
            else if (i == 1)
                func = "sort";
            else if (i == 2)
                func = "Find";
            else if (i == 3)
                func = "Cmp";

            tb.add_row({ func,
                         "", ToString(avr_time2[i][0]) + "ms", ToString(avr_time[i][0] / avr_time2[i][0]), ToString(results[i][0]),
                         "", ToString(avr_time2[i][1]) + "ms", ToString(avr_time[i][1] / avr_time2[i][1]), ToString(results[i][1]),
                         "", ToString(avr_time2[i][2]) + "ms", ToString(avr_time[i][2] / avr_time2[i][2]), ToString(results[i][2]),
                         "", ToString(avr_time2[i][3]) + "ms", ToString(avr_time[i][3] / avr_time2[i][3]), ToString(results[i][3]) });
        }

        tb.column(2).format().font_align(FontAlign::right);
        tb.column(3).format().font_align(FontAlign::right);
        tb.column(4).format().font_align(FontAlign::center);

        tb.column(6).format().font_align(FontAlign::right);
        tb.column(7).format().font_align(FontAlign::right);
        tb.column(8).format().font_align(FontAlign::center);

        tb.column(10).format().font_align(FontAlign::right);
        tb.column(11).format().font_align(FontAlign::right);
        tb.column(12).format().font_align(FontAlign::center);

        tb.column(14).format().font_align(FontAlign::right);
        tb.column(15).format().font_align(FontAlign::right);
        tb.column(16).format().font_align(FontAlign::center);

        for (size_t i = 0; i < tb.row(0).size(); ++i)
        {
            tb[0][i].format()
                .font_color(Color::yellow)
                .font_align(FontAlign::center)
                .font_style({ FontStyle::bold });
        }

        cout << tb << endl << endl;
    }
    return 0;
}


//не находить копии, если они уже отмечены
//добавить проверку по размеру файла

//при на ведение на дубликат карты выводить инфу о том почему они именно дубликат(установлена, по весу, по имени)
//отображать только те карты которые видно