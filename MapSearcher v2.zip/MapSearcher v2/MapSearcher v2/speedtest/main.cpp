﻿#include <iostream>
#include <vector>
#include <string>
#include <thread>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <queue>
#include <filesystem>
#include <Windows.h>
#include <execution>
#include <future>
#include <sstream>

#include "SimpleTimer.h"
#include "tabulate.hpp"

#include <zip.h>

using namespace tabulate;
namespace fs = std::filesystem;
using namespace std;

Timer timer;
vector<wstring> files;
vector<string> files2;
unordered_set<wstring> folders;
unordered_set<string> folders2;
vector<string> folders3;
vector<char> duplMaps;
vector<char> selMaps;
int countDuplMaps = 0;
int countSelMaps = 0;

wstring osu = L"F:\\osu!\\Songs";
vector<wstring> p = { L"C:\\Users\\Zipper\\Desktop\\0", L"C:\\Users\\Zipper\\Desktop\\1", L"C:\\Users\\Zipper\\Desktop\\2", L"C:\\Users\\Zipper\\Desktop\\3" };
vector<string> _p = { "C:\\Users\\Zipper\\Desktop\\0", "C:\\Users\\Zipper\\Desktop\\1", "C:\\Users\\Zipper\\Desktop\\2", "C:\\Users\\Zipper\\Desktop\\3" };

bool StrStartWith(const wstring& s1, const wstring& s2)
{
    return s2.size() <= s1.size() && s1.compare(0, s2.size(), s2) == 0;
}
bool StrCmpN(const wstring& s1, const wstring& s2, int n)
{
    for (int i = 0; i < n; ++i)
        if (!(s1[i] ^ s2[i]))
            return false;
    return true;
}


///////////////////////

void GetDirs1(unordered_set<string>& folders, const fs::path& path)
{
    folders.clear();
    for (const auto& entry : fs::directory_iterator(path))
        if (entry.is_directory())
        {
            u8string s = entry.path().filename().u8string();
            folders.emplace(string(s.begin(), s.end()));
        }
}

void GetFiles1(vector<string>& files, const fs::path& path, const char* extension)
{
    files.clear();
    for (const auto& entry : fs::directory_iterator(path))
        if (entry.is_regular_file() && entry.path().extension() == extension)
        {
            u8string s = entry.path().stem().u8string();
            files.push_back(string(s.begin(), s.end()));
        }
}
void GetFiles2(vector<string>& files, const string& path, const string& extension)
{
    string tmp = "";
    files.clear();

    for (const auto& entry : fs::directory_iterator(path))
    {
        if (entry.is_regular_file() && entry.path().extension() == extension)
        {
            tmp = reinterpret_cast<const char*>(entry.path().filename().u8string().data());
            files.push_back(tmp.substr(0, tmp.size() - extension.size()));
        }
    }
}

string DeleteSymbol(string str, const char& ch)
{
    str.erase(std::remove(str.begin(), str.end(), ch), str.end());
    return str;
}
string Replace(string str, const string old_str, const string new_str)
{
    size_t start{ str.find(old_str) };
    while (start != std::string::npos)
    {
        str.replace(start, old_str.length(), new_str);
        start = str.find(old_str, start + new_str.length());
    }
    return str;
}

void Find1()
{
#pragma omp parallel for
    for (int i = 0; i < files2.size(); ++i)
    {
        for (size_t j = 0; j < files2.size(); ++j)
        {
            if (i != j && files2[i].find(files2[j]) != std::string::npos)
            {
                duplMaps[i] = true;
                break;
            }
        }
    }
}
void Find2()
{
    string m1 = "", m2 = "";
    for (int i = 0; i < files2.size(); ++i)
    {
        for (int j = 0; j < files2.size(); ++j)
        {
            m1 = files2[i];
            m2 = files2[j];

            if (m1 == m2)
                continue;

            if (m1.size() < m2.size())
            {
                m2 = m2.substr(0, m1.size());
                if (m1 == m2)
                    duplMaps[j] = true;
            }
            else
            {
                m1 = m1.substr(0, m2.size());
                if (m1 == m2)
                    duplMaps[i] = true;
            }
        }
    }
}

void Cmp1()
{
#pragma omp parallel for num_threads(2)
    for (int i = 0; i < files2.size(); ++i)
        if (folders2.find(DeleteSymbol(files2[i], '.')) != folders2.end())
            duplMaps[i] = true;
}
void Cmp2()
{
    for (int i = 0; i < folders2.size(); ++i)
    {
        for (int j = 0; j < files2.size(); ++j)
        {
            if (folders3[i] == files2[j])
                duplMaps[j] = true;
            else if (folders3[i] == Replace(files2[j], ".", ""))
                duplMaps[j] = true;
        }
    }
}

///////////////////////


void GetFiles(vector<wstring>& files, const wstring& path, const wchar_t* extension)
{
    WIN32_FIND_DATAW findData;
    HANDLE hf;
    wstring name = L"";
    size_t pos = 0;
    files.clear();

    hf = FindFirstFileExW((path + L"\\*").c_str(), FindExInfoBasic, &findData, FindExSearchNameMatch, nullptr, FIND_FIRST_EX_LARGE_FETCH);
    if (hf == INVALID_HANDLE_VALUE)
        return;

    do
    {
        if (findData.dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE)
        {
            name = findData.cFileName;
            pos = name.rfind(extension);
            if (pos != string::npos)
                files.push_back(name.erase(pos));
        }
    } while (FindNextFileW(hf, &findData));

    FindClose(hf);
}
void GetDirs(unordered_set<wstring>& folders, const wstring& path)
{
    WIN32_FIND_DATAW findData;
    HANDLE hf;
    wstring name = L"";
    folders.clear();

    hf = FindFirstFileExW((path + L"\\*").c_str(), FindExInfoBasic, &findData, FindExSearchNameMatch, nullptr, 0);
    if (hf == INVALID_HANDLE_VALUE)
        return;

    do
    {
        if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
            folders.emplace(findData.cFileName);
    } while (FindNextFileW(hf, &findData));

    FindClose(hf);
}

void Cmp()
{
    const auto& end = folders.end();
    wstring tmp = L"";

    #pragma omp parallel for num_threads(2) private(tmp)
    for (int i = 0; i < files.size(); ++i)
    {
        tmp = files[i];
        std::erase(tmp, '.');
        if (folders.find(tmp) != end)
            duplMaps[i] = true;
    }
}
void Find()
{
    int N = files.size();
    for (int i = 0; i < N - 1; i++)
    {
        for (int j = 1; j < N - i; ++j)
        {
            if (files[i + j].find(files[i]) != std::string::npos)
                duplMaps[i + j] = true;
            else
            {
                i += j - 1;
                break;
            }
        }
    }
}

std::string ToString(double number)
{
    std::ostringstream stream;
    stream.precision(2); //знаки после зяпятой
    stream << std::fixed << number;
    return stream.str();
}

int main()
{
    vector<long double> sort_time{ 0.0, 0.0, 0.0, 0.0 };
    vector<vector<long double>> bad_times{ { 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0 } };
    vector<vector<long double>> best_times{ { 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0 } };
    long double bad_timeDirs = 0.0;
    long double best_timeDirs = 0.0;

    {
        Table tbDirs;
        tbDirs.add_row({ "Func", "Time", "Speedup", "Result" });

        int N = 10;
        long double avr_time = 0.0;
        long double slow_time = 0.0;

        for (int i = 0; i < N; ++i)
        {
            timer.Start();
            GetDirs1(folders2, osu);
            timer.Stop();
            avr_time += timer.GetTime().count();
        }
        avr_time /= N;
        slow_time = avr_time;

        tbDirs.add_row({ "GetDirs1", ToString(avr_time) + "ms", ToString(1.0), ToString(folders2.size())});

        for (int i = 0; i < N; ++i)
        {
            timer.Start();
            GetDirs(folders, osu);
            timer.Stop();
            avr_time += timer.GetTime().count();
        }
        avr_time /= N;

        tbDirs.add_row({ "GetDirs", ToString(avr_time) + "ms", ToString(slow_time / avr_time), ToString(folders.size()) });

        bad_timeDirs = slow_time;
        best_timeDirs = avr_time;

        tbDirs.column(1).format().font_align(FontAlign::right);
        tbDirs.column(2).format().font_align(FontAlign::right);
        tbDirs.column(3).format().font_align(FontAlign::center);

        for (size_t i = 0; i < 4; ++i)
        {
            tbDirs[0][i].format()
                .font_color(Color::yellow)
                .font_align(FontAlign::center)
                .font_style({ FontStyle::bold });

            tbDirs[2][i].format()
                .font_color(Color::green);
        }

        cout << tbDirs << endl << endl;
    }

    {
        Table tb;
        tb.add_row({ "Func", "", "p0", "Speedup", "Result", "", "p1", "Speedup", "Result", "", "p2", "Speedup", "Result", "", "p3", "Speedup", "Result" });

        int N = 10;
        vector<vector<long double>> avr_time{ { 0.0, 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0, 0.0 }, { 0.0, 0.0, 0.0, 0.0 } };
        vector<vector<int>> results{ { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } };
        vector<long double> bad_time;
        vector<pair<double, int>> pairs(3, { 0, 0 });
        vector<int> list_func(3, 0);

        //GetFiles
        if (true)
        {
            for (int i = 0; i < 4; ++i)
            {
                for (int j = 0; j < N; ++j)
                {
                    timer.Start();
                    GetFiles2(files2, _p[i], ".osz");
                    timer.Stop();
                    avr_time[0][i] += timer.GetTime().count();
                }
                results[0][i] = files2.size();
                avr_time[0][i] /= N;

                for (int j = 0; j < N; ++j)
                {
                    timer.Start();
                    GetFiles1(files2, _p[i], ".osz");
                    timer.Stop();
                    avr_time[1][i] += timer.GetTime().count();
                }
                results[1][i] = files2.size();
                avr_time[1][i] /= N;


                for (int j = 0; j < N; ++j)
                {
                    timer.Start();
                    GetFiles(files, p[i], L".osz");
                    timer.Stop();
                    avr_time[2][i] += timer.GetTime().count();
                }
                results[2][i] = files.size();
                avr_time[2][i] /= N;
            }


            for (int i = 0; i < 3; ++i)
            {
                pairs[i].second = i;

                for (int j = 0; j < 4; ++j)
                    pairs[i].first += avr_time[i][j];
            }
            sort(pairs.begin(), pairs.end());
            reverse(pairs.begin(), pairs.end());

            for (int i = 0; i < 3; ++i)
                list_func[i] = pairs[i].second;
            bad_time = avr_time[list_func[0]];

            for (int i = 0; i < 4; ++i)
            {
                bad_times[i][0] = avr_time[list_func[0]][i];
                best_times[i][0] = avr_time[list_func[2]][i];
            }


            for (int i = 0; i < 3; ++i)
            {
                int j = list_func[i];

                tb.add_row({ "GetFiles" + to_string(2 - j),
                             "", ToString(avr_time[j][0]) + "ms", ToString(bad_time[0] / avr_time[j][0]), ToString(results[j][0]),
                             "", ToString(avr_time[j][1]) + "ms", ToString(bad_time[1] / avr_time[j][1]), ToString(results[j][1]),
                             "", ToString(avr_time[j][2]) + "ms", ToString(bad_time[2] / avr_time[j][2]), ToString(results[j][2]),
                             "", ToString(avr_time[j][3]) + "ms", ToString(bad_time[3] / avr_time[j][3]), ToString(results[j][3]) });
            }
        }

        tb.add_row({ "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "" });
        for (const string& s : folders2)
            folders3.push_back(s);
        results = { { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } };

        //Cmp
        if (true)
        {
            for (int i = 0; i < 4; ++i)
            {
                GetFiles(files, p[i], L".osz");
                GetFiles1(files2, p[i], ".osz");
                duplMaps.assign(files.size(), false);

                for (int j = 0; j < 1; ++j)
                {
                    timer.Start();
                    Cmp2();
                    timer.Stop();
                    avr_time[0][i] += timer.GetTime().count();
                }
                avr_time[0][i] /= 1;
                for (char& f : duplMaps)
                {
                    results[0][i] += f ? 1 : 0;
                    f = false;
                }


                for (int j = 0; j < 2; ++j)
                {
                    timer.Start();
                    Cmp1();
                    timer.Stop();
                    avr_time[1][i] += timer.GetTime().count();
                }
                avr_time[1][i] /= 2;
                for (char& f : duplMaps)
                {
                    results[1][i] += f ? 1 : 0;
                    f = false;
                }


                for (int j = 0; j < 5; ++j)
                {
                    timer.Start();
                    Cmp();
                    timer.Stop();
                    avr_time[2][i] += timer.GetTime().count();
                }
                avr_time[2][i] /= 5;
                for (char& f : duplMaps)
                {
                    results[2][i] += f ? 1 : 0;
                    f = false;
                }
            }


            for (int i = 0; i < 3; ++i)
            {
                pairs[i].second = i;

                for (int j = 0; j < 4; ++j)
                    pairs[i].first += avr_time[i][j];
            }
            sort(pairs.begin(), pairs.end());
            reverse(pairs.begin(), pairs.end());

            for (int i = 0; i < 3; ++i)
                list_func[i] = pairs[i].second;
            bad_time = avr_time[list_func[0]];

            for (int i = 0; i < 4; ++i)
            {
                bad_times[i][1] = avr_time[list_func[0]][i];
                best_times[i][1] = avr_time[list_func[2]][i];
            }

            for (int i = 0; i < 3; ++i)
            {
                int j = list_func[i];

                tb.add_row({ "Cmp" + to_string(2 - j),
                             "", ToString(avr_time[j][0]) + "ms", ToString(bad_time[0] / avr_time[j][0]), ToString(results[j][0]),
                             "", ToString(avr_time[j][1]) + "ms", ToString(bad_time[1] / avr_time[j][1]), ToString(results[j][1]),
                             "", ToString(avr_time[j][2]) + "ms", ToString(bad_time[2] / avr_time[j][2]), ToString(results[j][2]),
                             "", ToString(avr_time[j][3]) + "ms", ToString(bad_time[3] / avr_time[j][3]), ToString(results[j][3]) });
            }
        }

        tb.add_row({ "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "" });
        results = { { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } };

        //Find
        if (true)
        {
            for (int i = 0; i < 4; ++i)
            {
                GetFiles(files, p[i], L".osz");
                GetFiles1(files2, p[i], ".osz");

                timer.Start();
                std::sort(files.begin(), files.end());
                timer.Stop();
                sort_time[i] = timer.GetTime().count();

                duplMaps.assign(files.size(), false);
                for (int j = 0; j < 1; ++j)
                {
                    timer.Start();
                    Find2();
                    timer.Stop();
                    avr_time[0][i] += timer.GetTime().count();
                }
                avr_time[0][i] /= 1;
                for (char& f : duplMaps)
                {
                    results[0][i] += f ? 1 : 0;
                    f = false;
                }

                duplMaps.assign(files.size(), false);
                for (int j = 0; j < 10; ++j)
                {
                    timer.Start();
                    Find1();
                    timer.Stop();
                    avr_time[1][i] += timer.GetTime().count();
                }
                avr_time[1][i] /= 10;
                for (char& f : duplMaps)
                {
                    results[1][i] += f ? 1 : 0;
                    f = false;
                }

                duplMaps.assign(files.size(), false);
                for (int j = 0; j < 10; ++j)
                {
                    timer.Start();
                    Find();
                    timer.Stop();
                    avr_time[2][i] += timer.GetTime().count();
                }
                avr_time[2][i] /= 10;
                for (char& f : duplMaps)
                {
                    results[2][i] += f ? 1 : 0;
                    f = false;
                }
            }


            for (int i = 0; i < 3; ++i)
            {
                pairs[i].second = i;

                for (int j = 0; j < 4; ++j)
                    pairs[i].first += avr_time[i][j];
            }
            sort(pairs.begin(), pairs.end());
            reverse(pairs.begin(), pairs.end());

            for (int i = 0; i < 3; ++i)
                list_func[i] = pairs[i].second;
            bad_time = avr_time[list_func[0]];

            for (int i = 0; i < 4; ++i)
            {
                bad_times[i][2] = avr_time[list_func[0]][i];
                best_times[i][2] = avr_time[list_func[2]][i];
            }

            for (int i = 0; i < 3; ++i)
            {
                int j = list_func[i];

                tb.add_row({ "Find" + to_string(2 - j),
                             "", ToString(avr_time[j][0]) + "ms", ToString(bad_time[0] / avr_time[j][0]), ToString(results[j][0]),
                             "", ToString(avr_time[j][1]) + "ms", ToString(bad_time[1] / avr_time[j][1]), ToString(results[j][1]),
                             "", ToString(avr_time[j][2]) + "ms", ToString(bad_time[2] / avr_time[j][2]), ToString(results[j][2]),
                             "", ToString(avr_time[j][3]) + "ms", ToString(bad_time[3] / avr_time[j][3]), ToString(results[j][3]) });
            }
        }

        tb.column(2).format().font_align(FontAlign::right);
        tb.column(3).format().font_align(FontAlign::right);
        tb.column(4).format().font_align(FontAlign::center);

        tb.column(6).format().font_align(FontAlign::right);
        tb.column(7).format().font_align(FontAlign::right);
        tb.column(8).format().font_align(FontAlign::center);

        tb.column(10).format().font_align(FontAlign::right);
        tb.column(11).format().font_align(FontAlign::right);
        tb.column(12).format().font_align(FontAlign::center);

        tb.column(14).format().font_align(FontAlign::right);
        tb.column(15).format().font_align(FontAlign::right);
        tb.column(16).format().font_align(FontAlign::center);

        for (size_t i = 0; i < tb.row(0).size(); ++i)
        {
            tb[0][i].format()
                .font_color(Color::yellow)
                .font_align(FontAlign::center)
                .font_style({ FontStyle::bold });

            tb[1][i].format().font_color(Color::red);
            tb[3][i].format().font_color(Color::green);

            tb[5][i].format().font_color(Color::red);
            tb[7][i].format().font_color(Color::green);

            tb[9][i].format().font_color(Color::red);
            tb[11][i].format().font_color(Color::green);
        }

        cout << tb << endl << endl;
    }

    {
        Table tb;

        tb.add_row({ "Func", "p0", "p1", "p2", "p3" });
        tb.add_row({ "sort",  ToString(sort_time[0]), ToString(sort_time[1]), ToString(sort_time[2]), ToString(sort_time[3]) });

        cout << "Sort time:" << endl;
        cout << tb << endl << endl;
    }

    {
        Table tb;

        tb.add_row({ "Files", "GetDirs", "GetFiles", "Cmp", "Find", "Full time" });

        long double full_time = 0.0;
        for (int i = 0; i < 4; ++i)
        {
            full_time = bad_timeDirs + bad_times[i][0] + bad_times[i][1] + bad_times[i][2];
            tb.add_row({ "p" + to_string(i), ToString(bad_timeDirs), ToString(bad_times[i][0]), ToString(bad_times[i][1]), ToString(bad_times[i][2]), ToString(full_time) });
        }

        cout << "Bad time:" << endl;
        cout << tb << endl << endl;
    }

    {
        Table tb;

        tb.add_row({ "Files", "GetDirs", "GetFiles", "Cmp", "Find", "Full time" });

        long double full_time = 0.0;
        for (int i = 0; i < 4; ++i)
        {
            full_time = best_timeDirs + best_times[i][0] + best_times[i][1] + best_times[i][2];
            tb.add_row({ "p" + to_string(i), ToString(best_timeDirs), ToString(best_times[i][0]), ToString(best_times[i][1]), ToString(best_times[i][2]), ToString(full_time) });
        }

        cout << "Best time:" << endl;
        cout << tb << endl << endl;
    }

    {
        Table tb;

        tb.add_row({ "Files", "With sort", "Without sort" });

        for (int i = 0; i < 4; ++i)
        {
            long double bad_full_time = bad_timeDirs + bad_times[i][0] + bad_times[i][1] + bad_times[i][2];
            long double best_full_time = best_timeDirs + best_times[i][0] + best_times[i][1] + best_times[i][2];

            tb.add_row({ "p" + to_string(i), ToString((bad_full_time + sort_time[i]) / (best_full_time + sort_time[i])), ToString(bad_full_time / best_full_time)});
        }

        cout << "Speedup full:" << endl;
        cout << tb << endl << endl;
    }

    string ins = "";
    cin >> ins;

    return 0;
}