#include "Menu.h"
#include "Window.h"
#include "imgui/imgui_internal.h"
#include "SimpleTimer.h"

#include <Windows.h>
#include <tlhelp32.h>
#include <ShlObj.h>
#include <vector>
#include <string>
#include <thread>
#include <unordered_set>
#include <filesystem>

namespace fs = std::filesystem;
using std::string;
using std::wstring;
using std::vector;
using std::thread;
using std::unordered_set;

constexpr const ImGuiWindowFlags MENU_FLAGS = (ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_HorizontalScrollbar);

struct File
{
    wstring name = L"";
    unsigned long weight = 0;
};
struct OSUData
{
    wstring osuPath = L"";					// ���� � osu!
	wstring installedMapsPath = L"";		// ���� � ������ osu!
	wstring downloadMapsPath = L"";			// ���� � ��������� ������
	string tmpPath = "";			        // ��������� ����
    int downloadMapsPathSelect = 0;         // ��������� ����� ��� ��������� ����

    unordered_set<wstring> folders;         // ������ ������������� ����
    vector<File> files;                     // ������ ��������� ����
    vector<char> duplMaps;                  // ������ ������������� ����
    vector<char> selMaps;                   // ������ ��������� ����

    int countFiles = 0;                     // ���-�� ����

    int countDuplMaps = 0;                  // ���-�� ������������� ����
    int countNewMaps = 0;                   // ���-�� ����� ����
    int countInstMaps = 0;                  // ���-�� ������������� ����
    int countSelMaps = 0;                   // ���-�� ��������� ����

    int countSelNewMaps = 0;                // ���-�� ��������� � ����� ����
    int countSelDuplMaps = 0;               // ���-�� ��������� � ������������� ����
    int countSelInstMaps = 0;               // ���-�� ��������� � ������������� ����

    bool isDeleteMaps = false;              // �������� ����
    bool isRefreshData = false;             // ���� ��� ������ ������, �� ����� ���������� ������

    string errors = "";                     // ������ ��� ������ ������
    //std::error_code errors;
} data;
const vector<const char*> listMapsFolders = { u8"������� ����", u8"��������", u8"����" };
const vector<ImColor> colors = { ImColor(1.f, 1.f, 1.f), ImColor(1.f, 1.f, 0.f), ImColor(1.f, 0.f, 0.f) };

void wstr2str(const wstring& wstr, string& str)
{
    if (wstr.empty())
    {
        str = std::string();
        return;
    }

    int utf8_size = WideCharToMultiByte(CP_UTF8, 0, &wstr[0], wstr.size(), nullptr, 0, nullptr, nullptr);
    str.assign(utf8_size, '\0');
    WideCharToMultiByte(CP_UTF8, 0, &wstr[0], wstr.size(), &str[0], utf8_size, nullptr, nullptr);
}
void str2wstr(const string& str, wstring& wstr)
{
    if (str.empty())
    {
        wstr = std::wstring();
        return;
    }

    int utf8_size = MultiByteToWideChar(CP_UTF8, 0, &str[0], str.size(), nullptr, 0);
    wstr.assign(utf8_size, '\0');
    MultiByteToWideChar(CP_UTF8, 0, &str[0], str.size(), &wstr[0], utf8_size);
}

template <class _Elem, class _Traits, class _Alloc, class _Uty>
constexpr size_t erase(std::basic_string<_Elem, _Traits, _Alloc>& _Cont, const _Uty& _Val)
{
    return std::_Erase_remove(_Cont, _Val);
}
template <class _Elem, class _Traits, class _Alloc, class _Pr>
constexpr size_t erase_if(std::basic_string<_Elem, _Traits, _Alloc>& _Cont, _Pr _Pred)
{
    return std::_Erase_remove_if(_Cont, std::_Pass_fn(_Pred));
}

void GetDesktopPath(wstring& path)
{
    wchar_t* _path = nullptr;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_Desktop, 0, NULL, &_path)))
        path = _path;
    else
        path = L"";
    CoTaskMemFree(_path);
}
void GetDownloadsPath(wstring& path)
{
    wchar_t* _path = nullptr;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_Downloads, 0, NULL, &_path)))
        path = _path;
    else
        path = L"";
    CoTaskMemFree(_path);
}
bool OpenBrowseFolder(wstring& path) // �������� ������� ��� ������ �����
{
	IFileDialog* pFileDialog;

    // �������� ������� ������ ������
    HRESULT hr = CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_ALL, IID_PPV_ARGS(&pFileDialog));

    if (SUCCEEDED(hr))
    {
		pFileDialog->SetTitle(L"�������� �����");
        // ��������� ����� ��� ������ �����
        pFileDialog->SetOptions(FOS_PICKFOLDERS);

        // �������� �������
        hr = pFileDialog->Show(nullptr);

        if (SUCCEEDED(hr))
        {
            IShellItem* pItem;
            hr = pFileDialog->GetResult(&pItem);

            if (SUCCEEDED(hr))
            {
                // ��������� ���� � ��������� �����
                PWSTR pszFilePath;
                if (SUCCEEDED(pItem->GetDisplayName(SIGDN_FILESYSPATH, &pszFilePath)))
                {
                    path = pszFilePath;
                    CoTaskMemFree(pszFilePath);
                    pItem->Release();
                    pFileDialog->Release();
                    return true;
                }
                pItem->Release();
            }
        }
        pFileDialog->Release();
    }
    path = L"";
    return false;
}

void GetProcessPathByName(const wchar_t* processName, wstring& path)
{
    PROCESSENTRY32 pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32);

    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE)
    {
        path = L"";
        return;
    }

    if (!Process32First(hSnapshot, &pe32))
    {
        CloseHandle(hSnapshot);
        path = L"";
        return;
    }

    DWORD pid = 0;
    do {
        if (!wcscmp(pe32.szExeFile, processName))
        {
            pid = pe32.th32ProcessID;
            break;
        }
    } while (Process32Next(hSnapshot, &pe32));

    CloseHandle(hSnapshot);

    if (pid == 0)
    {
        path = L"";
        return;
    }

    HANDLE hProcess = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (hProcess == NULL)
    {
        path = L"";
        return;
    }

    wchar_t processPath[MAX_PATH];
    DWORD pathSize = sizeof(processPath);
    if (!QueryFullProcessImageNameW(hProcess, 0, processPath, &pathSize))
    {
        CloseHandle(hProcess);
        path = L"";
        return;
    }

    CloseHandle(hProcess);

    path = processPath;
    path.erase(path.size() - (wcslen(processName) + 1));
}
void GetInstalledAppPath(const wchar_t* appName, wstring& path)
{
    HKEY hKey;
    const wchar_t* uninstallKey = L"SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall";
    const wchar_t* appNameKey = L"DisplayName";
    const wchar_t* appPathKey = L"DisplayIcon";
    const DWORD buffersSize = 1024;
    DWORD bufferSize = buffersSize;
    wchar_t buffer[buffersSize];
    wchar_t nameBuffer[buffersSize];

    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, uninstallKey, 0, KEY_READ, &hKey) == ERROR_SUCCESS)
    {
        DWORD index = 0;
        while (RegEnumKeyExW(hKey, index, buffer, &bufferSize, nullptr, nullptr, nullptr, nullptr) == ERROR_SUCCESS)
        {
            HKEY appKey;
            if (RegOpenKeyExW(hKey, buffer, 0, KEY_READ, &appKey) == ERROR_SUCCESS)
            {
                bufferSize = buffersSize;
                if (RegQueryValueExW(appKey, appNameKey, nullptr, nullptr, (LPBYTE)nameBuffer, &bufferSize) == ERROR_SUCCESS)
                {
                    if (!wcscmp(nameBuffer, appName))
                    {
                        bufferSize = buffersSize;
                        if (RegQueryValueExW(appKey, appPathKey, nullptr, nullptr, (LPBYTE)nameBuffer, &bufferSize) == ERROR_SUCCESS)
                        {
                            RegCloseKey(appKey);
                            RegCloseKey(hKey);
                            path = nameBuffer;
                            path.erase(path.size() - (wcslen(appName) + 5));
                            return;
                        }
                    }
                }
                RegCloseKey(appKey);
            }
            index++;
            bufferSize = 1024;
        }
        RegCloseKey(hKey);
    }
    path = L"";
}

bool SaveDataRegedit()
{
    HKEY hSubKey;
    if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\MapSearcher", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hSubKey, NULL) != ERROR_SUCCESS)
        return false;

    string tmp;
    wstr2str(data.osuPath, tmp);
    RegSetValueExA(hSubKey, "osuPath", 0, REG_SZ, reinterpret_cast<const BYTE*>(&tmp[0]), static_cast<DWORD>((tmp.size() + 1) * sizeof(char)));

    RegSetValueExA(hSubKey, "downloadMapsPathSelect", 0, REG_DWORD, reinterpret_cast<const BYTE*>(&data.downloadMapsPathSelect), sizeof(DWORD));
    if (data.downloadMapsPathSelect == 2)
    {
        wstr2str(data.downloadMapsPath, tmp);
        RegSetValueExA(hSubKey, "downloadMapsPath", 0, REG_SZ, reinterpret_cast<const BYTE*>(&tmp[0]), static_cast<DWORD>((tmp.size() + 1) * sizeof(char)));
    }

    RegCloseKey(hSubKey);
    return true;
}
void LoadDataRegedit()
{
    HKEY hSubKey;
    if (RegOpenKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\MapSearcher", 0, KEY_READ, &hSubKey) != ERROR_SUCCESS)
        return;

    DWORD dataSize = 0;
    if (RegQueryValueExA(hSubKey, "osuPath", NULL, NULL, NULL, &dataSize) == ERROR_SUCCESS)
    {
        char* buffer = new char[dataSize];
        if (RegQueryValueExA(hSubKey, "osuPath", NULL, NULL, reinterpret_cast<LPBYTE>(buffer), &dataSize) == ERROR_SUCCESS)
        {
            str2wstr(buffer, data.osuPath);
            data.installedMapsPath = data.osuPath + L"\\Songs";
        }
        delete[] buffer;
    }

    dataSize = sizeof(DWORD);
    RegQueryValueExA(hSubKey, "downloadMapsPathSelect", NULL, NULL, reinterpret_cast<LPBYTE>(&data.downloadMapsPathSelect), &dataSize);

    if (data.downloadMapsPathSelect == 2 && RegQueryValueExA(hSubKey, "downloadMapsPath", NULL, NULL, NULL, &dataSize) == ERROR_SUCCESS)
    {
        char* buffer = new char[dataSize];
        if (RegQueryValueExA(hSubKey, "downloadMapsPath", NULL, NULL, reinterpret_cast<LPBYTE>(buffer), &dataSize) == ERROR_SUCCESS)
            str2wstr(buffer, data.downloadMapsPath);
        delete[] buffer;
    }

    RegCloseKey(hSubKey);
}


void GetDirs(unordered_set<wstring>& folders, const wstring& path)
{
    WIN32_FIND_DATAW findData;
    HANDLE hf;
    string name = "";
    folders.clear();

    hf = FindFirstFileExW((path + L"\\*").c_str(), FindExInfoBasic, &findData, FindExSearchNameMatch, nullptr, 0);
    if (hf == INVALID_HANDLE_VALUE)
        return;

    do
    {
        if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
            folders.emplace(findData.cFileName);
    } while (FindNextFileW(hf, &findData));

    FindClose(hf);
}
void GetFiles(vector<File>& files, const wstring& path, const wchar_t* extension)
{
    WIN32_FIND_DATAW findData;
    HANDLE hf;
    wstring name = L"";
    size_t pos = 0;
    files.clear();

    hf = FindFirstFileExW((path + L"\\*").c_str(), FindExInfoBasic, &findData, FindExSearchNameMatch, nullptr, FIND_FIRST_EX_LARGE_FETCH);
    if (hf == INVALID_HANDLE_VALUE)
        return;

    File f;
    do
    {
        if (findData.dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE)
        {
            name = findData.cFileName;
            pos = name.rfind(extension);
            if (pos != string::npos)
            {
                f.name = name.erase(pos);
                f.weight = (findData.nFileSizeHigh * (MAXDWORD + 1)) + findData.nFileSizeLow;
                files.push_back(f);
            }
        }
    } while (FindNextFileW(hf, &findData));

    FindClose(hf);
}
void Find() // �������� �� ���������
{
    const int N = data.files.size();
    for (int i = 0; i < N - 1; i++)
    {
        File& file1 = data.files[i];
        for (int j = 1; j < N - i; ++j)
        {
            File& file2 = data.files[i + j];

            if (file2.name.find(file1.name) != std::string::npos && file2.weight == file1.weight)
                data.duplMaps[i + j] = 1;
            else
            {
                i += j - 1;
                break;
            }
        }
    }
}
void Cmp() // ��������, ����������� �� �����
{
    const auto& end = data.folders.end();
    wstring tmp = L"";
    const int N = data.files.size();

    #pragma omp parallel for num_threads(2) private(tmp)
    for (int i = 0; i < N; ++i)
    {
        if (data.duplMaps[i])
            continue;

        tmp = data.files[i].name;
        erase(tmp, '.');
        //tmp.erase(std::remove(tmp.begin(), tmp.end(), '.'), tmp.end());

        if (data.folders.find(tmp) != end)
            data.duplMaps[i] = 2;
    }
}

void GetData()
{
    data.isRefreshData = true;
    data.countFiles = 0;

    GetDirs(data.folders, data.installedMapsPath);
    GetFiles(data.files, data.downloadMapsPath, L".osz");

    data.duplMaps.assign(data.files.size(), false);
    std::sort(data.files.begin(), data.files.end(), [](const File& a, const File& b) { return a.name < b.name; });

    Find();
    Cmp();

    data.countInstMaps = data.countDuplMaps = 0;
    for (const char& flag : data.duplMaps)
    {
        if (flag == 1)
            ++data.countDuplMaps;
        else if (flag == 2)
            ++data.countInstMaps;
    }

    data.selMaps = data.duplMaps;
    data.countSelMaps = data.countDuplMaps + data.countInstMaps;
    data.countNewMaps = data.files.size() - data.countSelMaps;

    data.isRefreshData = false;
}
void RefreshData()
{
    data.errors = "";

    if (data.installedMapsPath.empty() || !fs::is_directory(data.installedMapsPath))
    {
        data.errors = u8"����������� ������ ���� � ����� osu!";
        return;
    }

    if (data.downloadMapsPath.empty() || !fs::is_directory(data.downloadMapsPath))
    {
        data.errors = u8"����������� ������ ���� � ����� c �������";
        return;
    }

    //GetData();
    thread dataUpdateThread(GetData);
    dataUpdateThread.detach();
}


void DrawListMaps()
{
    if (ImGui::BeginChild("Map list", ImVec2(Window::GetSize().x - 450, 0), ImGuiChildFlags_Borders, ImGuiWindowFlags_HorizontalScrollbar))
    {
        ImGuiWindow* window = ImGui::GetCurrentWindow();
        ImGuiStyle& style = ImGui::GetStyle();

        int windowHeight = window->Size.y; // ������ ����
        int scroll = window->Scroll.y; // ��������� scroll bar
        int itemSpacing = style.ItemSpacing.y; // ���������� ����� ����������
        int windowPad = style.WindowPadding.y; // ���������� �� ����
        int heightElem = ImGui::GetFontSize() + style.FramePadding.y * 2.0f; // ������ ��������
        float fullHeightElem = heightElem + itemSpacing; // ������ �������� c �����������

        // ��������� �������� ������� ��������
        int firstElem = static_cast<int>((scroll - (windowPad - 1) + itemSpacing) / fullHeightElem);

        // ��������� ��������� �������
        int lastElem = static_cast<int>((scroll - (windowPad - 1) + windowHeight - (itemSpacing - 1)) / fullHeightElem) + 1;
        lastElem = ImMin(lastElem, data.countFiles);

        for (int i = firstElem; i < lastElem; ++i)
        {
            ImGui::SetCursorPosY(fullHeightElem * i + windowPad);
            if (ImGui::Checkbox(("##" + std::to_string(i)).c_str(), (bool*)&data.selMaps[i]))
            {
                if (data.selMaps[i])
                    data.countSelMaps++;
                else
                    data.countSelMaps--;
            }
            ImGui::SameLine();
            wstr2str(data.files[i].name, data.tmpPath);
            ImGui::TextColored(colors[data.duplMaps[i]], data.tmpPath.c_str());
        }

        ImGui::SetCursorPosY(data.countFiles * fullHeightElem - itemSpacing + windowPad);
    }
    ImGui::EndChild();
}
void AddSpace()
{
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 15);
    ImGui::Separator();
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 15);
}
void DrawSettingsMenu()
{
    if (ImGui::BeginChild("Settings", ImVec2(0, 0), ImGuiChildFlags_Borders))
    {
        ImGui::Text(u8"���� � osu!");
        ImGui::SetNextItemWidth(300);
        wstr2str(data.osuPath, data.tmpPath);
        if (ImGui::InputText("##OsuPath", &data.tmpPath))
        {
            str2wstr(data.tmpPath, data.osuPath);
            data.installedMapsPath = data.osuPath + L"\\Songs";
            RefreshData();
        }
        ImGui::SameLine();
        if (ImGui::Button(u8"�������##1", ImVec2(100, 0)))
        {
            wstring tmp = L"";
            if (OpenBrowseFolder(tmp))
            {
                data.osuPath = tmp;
                data.installedMapsPath = data.osuPath + L"\\Songs";
                RefreshData();
            }
        }

        ImGui::Text(u8"\n���� � ����� � �������");
        ImGui::SetNextItemWidth(300);
        if (ImGui::Combo("##mapsPath", &data.downloadMapsPathSelect, listMapsFolders.data(), 3))
        {
            if (data.downloadMapsPathSelect == 0)
                GetDesktopPath(data.downloadMapsPath);
            else if (data.downloadMapsPathSelect == 1)
                GetDownloadsPath(data.downloadMapsPath);
            RefreshData();
        }
        if (data.downloadMapsPathSelect == 2)
        {
            ImGui::SetNextItemWidth(300);
            wstr2str(data.downloadMapsPath, data.tmpPath);
            if (ImGui::InputText("##MapsPath", &data.tmpPath))
            {
                str2wstr(data.tmpPath, data.downloadMapsPath);
                RefreshData();
            }
            ImGui::SameLine();
            if (ImGui::Button(u8"�������##2", ImVec2(100, 0)))
            {
                wstring tmp = L"";
                if (OpenBrowseFolder(tmp))
                {
                    data.downloadMapsPath = tmp;
                    RefreshData();
                }
            }
        }

        AddSpace();

        if (ImGui::Button(u8"��������", ImVec2(200, 50)))
            RefreshData();
        ImGui::SameLine();
        ImGui::BeginDisabled(!data.countFiles || !data.countSelMaps);
        if (ImGui::Button(u8"������� ���������", ImVec2(200, 50)))
        {
            data.isDeleteMaps = true;

            data.countSelNewMaps = data.countSelDuplMaps = data.countSelInstMaps = 0;
            for (int i = 0; i < data.countFiles; ++i)
            {
                if (data.selMaps[i])
                {
                    if (data.duplMaps[i] == 0)
                        data.countSelNewMaps++;
                    else if (data.duplMaps[i] == 1)
                        data.countSelDuplMaps++;
                    else if (data.duplMaps[i] == 2)
                        data.countSelInstMaps++;
                }
            }
        }
        ImGui::EndDisabled();

        AddSpace();

        ImGui::Text((u8"���-�� ����: " + std::to_string(data.countFiles)).c_str());
        ImGui::Text((u8"���-�� ����� ����: " + std::to_string(data.countNewMaps)).c_str());
        ImGui::Text((u8"���-�� ������������� ����: " + std::to_string(data.countDuplMaps)).c_str());
        ImGui::Text((u8"���-�� ������������� ����: " + std::to_string(data.countInstMaps)).c_str());
        ImGui::Text((u8"���-�� ��������� ����: " + std::to_string(data.countSelMaps)).c_str());

        AddSpace();

        ImGui::TextColored(ImColor(1.f, 0.f, 0.f), data.errors.c_str());
    }
    ImGui::EndChild();
}
void DrawMainMenu()
{
	ImGui::SetNextWindowPos(point());
	ImGui::SetNextWindowSize(Window::GetSize());
	if (ImGui::Begin("MapSearcher", nullptr, MENU_FLAGS))
	{
        DrawListMaps();
        ImGui::SameLine();
        DrawSettingsMenu();
	}
	ImGui::End();

    //ImGui::ShowDemoWindow();
}

void DeleteSelectMaps()
{
    data.isRefreshData = true;
    data.countFiles = 0;

    wstring folder = data.downloadMapsPath + L"\\";
    wstring file = L"";

    for (int i = 0; i < data.files.size(); ++i)
        if (data.selMaps[i])
            DeleteFileW((folder + data.files[i].name + L".osz").c_str());

    RefreshData();
}
void DrawConfirmationMenu() // ���� ������������� �������� ����
{
    ImGui::SetNextWindowPos(point());
    ImGui::SetNextWindowSize(Window::GetSize());
    if (ImGui::Begin("DeleteMaps", 0, MENU_FLAGS))
    {
        int posY = Window::GetSize().y / 2.f;
        ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(0, posY - 100), ImVec2(Window::GetSize().x, posY + 100), ImColor(255, 100, 0));

        ImGui::SetCursorPosY(posY - 55);
        ImGui::Indent(30);
        ImGui::Text((u8"������� ����: " + std::to_string(data.countSelMaps)).c_str());
        ImGui::BulletText((u8"�����: " + std::to_string(data.countSelNewMaps)).c_str());
        ImGui::BulletText((u8"�������������: " + std::to_string(data.countSelDuplMaps)).c_str());
        ImGui::BulletText((u8"�������������: " + std::to_string(data.countSelInstMaps)).c_str());
        ImGui::Unindent(30);

        ImGui::SetCursorPos(ImVec2(Window::GetSize().x - 320, posY + 50));
        if (ImGui::IsKeyDown(ImGuiKey_Enter) || ImGui::Button(u8"�������", ImVec2(150, 40)))
        {
            thread deleteMapsThread(DeleteSelectMaps);
            deleteMapsThread.detach();
            //DeleteSelectMaps();
            data.isDeleteMaps = false;
        }
        ImGui::SameLine();
        if (ImGui::IsKeyDown(ImGuiKey_Escape) || ImGui::Button(u8"������", ImVec2(150, 40)))
            data.isDeleteMaps = false;
    }
    ImGui::End();
}


bool Menu::Init()
{
	Window::SetFPSLimitMode(2, 60);
	CoInitialize(NULL);

    LoadDataRegedit();

    if (data.osuPath == L"")
        GetProcessPathByName(L"osu!.exe", data.osuPath);
    if (data.osuPath == L"")
        GetInstalledAppPath(L"osu!", data.osuPath);

    if (data.osuPath != L"" && data.installedMapsPath == L"")
        data.installedMapsPath = data.osuPath + L"\\Songs";


    if (data.downloadMapsPathSelect == 0)
        GetDesktopPath(data.downloadMapsPath);
    else if (data.downloadMapsPathSelect == 1)
        GetDownloadsPath(data.downloadMapsPath);

    if (data.downloadMapsPath == L"")
        GetDesktopPath(data.downloadMapsPath);

    RefreshData();

	return true;
}
void Menu::Destroy()
{
	CoUninitialize();
    SaveDataRegedit();
}

void Menu::Draw()
{
    data.countFiles = data.isRefreshData ? 0 : data.files.size();
    if (data.isDeleteMaps)
        DrawConfirmationMenu();
	DrawMainMenu();
}