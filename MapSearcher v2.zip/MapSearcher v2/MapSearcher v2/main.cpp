#include "Window.h"


int WinMain(int, char**)
{
	Window::Init();
	Window::Create("MapSearcher v2", point(1280, 720));
	Window::Run();
	Window::Destroy();

	return 0;
}