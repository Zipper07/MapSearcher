#pragma once

class Menu
{
public:
    static bool Init();
    static void Draw();
    static void Destroy();
};